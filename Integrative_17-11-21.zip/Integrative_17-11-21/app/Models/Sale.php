<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    use HasFactory;
    protected $table = 'sales';
    protected $fillable = [
        'user_id',
        'discount_type',
        'discount_amount',
        'event_price',
        'selling_price',
        'start_date',
        'end_date'
    ];
}
