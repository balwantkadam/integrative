<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Sale;

use Illuminate\Support\Facades\Auth;
class SaleApiController extends Controller
{
    public function getAllSale() {
        // logic to get all record goes here
        $sales = Sale::get()->toJson(JSON_PRETTY_PRINT);
        return response($sales, 200);
      }
  
      public function createSale(Request $request) {
        // logic to create a  record goes here
        // Get the currently authenticated user...
            $user = Auth::user();
            //dd($user);
         // Get the currently authenticated user's ID...
            $id =1 ;
            $sale = new Sale;
            $sale->user_id = $id;
            $sale->discount_type  = $request->discount_type;
            $sale->discount_amount = $request->discount_amount;
            $sale->event_price =  $request->event_price;
            $sale->selling_price = $request->selling_price;
            $sale->start_date = $request->start_date;
            $sale->end_date = $request->end_date;
            $sale->save();
        
            return response()->json([
                "message" => "Sale Event record created"
            ], 201);
          
      }
  
      public function getSale($id) {
        // logic to get a  record goes here
        if (Sale::where('id', $id)->exists()) {
            $sale = Sale::where('id', $id)->get()->toJson(JSON_PRETTY_PRINT);
            return response($sale, 200);
          } else {
            return response()->json([
              "message" => "Student not found"
            ], 404);
          }
      }
  
     
}
