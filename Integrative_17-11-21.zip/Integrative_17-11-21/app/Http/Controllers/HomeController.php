<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Sale;
use Illuminate\Support\Facades\Auth;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $sales=Sale::where('sales.id','!=',0)
        ->join('users','users.id','=','sales.user_id')
        ->select('users.*','sales.*')
        ->get();
        //dd($users);
         return view('home',compact('sales'));
    }
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'discount_type' => 'required',
            'discount_amount' => 'required|numeric',
            'event_price' => 'required|numeric',
            'selling_price' =>'required|numeric',
            'start_date' => 'required',
            'end_date' => 'required'
        ]);
            $user_id = Auth::user()->id;
            $sale = new Sale;
            $sale->user_id =$user_id ;
            $sale->discount_type  = $request->discount_type;
            $sale->discount_amount = $request->discount_amount;
            $sale->event_price =  $request->event_price;
            $sale->selling_price = $request->selling_price;
            $sale->start_date = $request->start_date;
            $sale->end_date = $request->end_date;
            $sale->save();
          return redirect()->back()->with('success', 'Record  created successfully.');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   
    public function destroy($id)
    {
        $sale = Sale::findOrFail($id);
        $sale->delete();
        return redirect('/home');
    }

}
