<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-2 sidenav bg-primary">
      <h4>SALE EVENT PANEL </h4>
      
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search..">
        
      </div>
      <hr>
      <ul class="nav nav-pills nav-stacked">
    
        <li class="active"><a style="color:green" href="">List of Sale Events</a></li>
    
      </ul>

      <br>
     
    </div>
    <div>
   
</div>
    <div class="col-sm-10" >
    <?php if($message = Session::get('success')): ?>
  <div class="alert alert-primary" role="alert">
  Record Created successfully !
  </div> 
   <?php endif; ?>  
   
  
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
     
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
      <h4><small>ADD SALE EVENT</small></h4>
      <hr>
  <form action="<?php echo e(route('homes.store')); ?>" class="form-horizontal ws-validate" id="myForm"  method="POST">
    <?php echo csrf_field(); ?>
    <div>
    <div class="row">
    <div class="col-md-6">
    <label for="discount_type" class="control-label required">Discount Type</label>
    <br>
  <input type="radio" id="discount_type" name="discount_type" value="%">
  <label for="percentage">%</label><br>
  <input type="radio" id="doller" name="discount_type" value="$">
  <label for="doller">$</label><br>
   </div>
    <div class="col-md-6">
        <label for="discount_amount" class="control-label required">Discount Amount</label>
        <input type="text" class="form-control" id="discount_amount"  name="discount_amount" placeholder="Discount Amount" required />
    </div>
    </div>
    <div class="row">
    <div class="col-md-6">
        <label for="event_price" class="control-label required">Event Price</label>
        <input type="number" class="form-control" id="event_price" name="event_price" placeholder="Event Price" required />
    </div>
    <div class="col-md-6">
        <label for="selling_price" class="control-label required">Selling Price</label>
        <input type="number" class="form-control" id="selling_price" name="selling_price" placeholder="Selling Price" required />
    </div>
    </div>
    <div class="row">
    <div class="col-md-6">
        <label for="start_date" class="control-label required">Start Date</label>
        <input type="date" class="form-control" id="start_date"  name="start_date" placeholder="Start Date" />
    </div>
    <div class="col-md-6">
        <label for="end_date" class="control-label required">End Date</label>
        <input type="date" class="form-control" id="end_date"  name="end_date" placeholder="End Date"  />
    </div>
    </div>
    <br>
    <div class="row">
    <div class="col-md-6">
        <button type="submit" class="btn btn-primary">Save</button>
        <button class="btn btn-primary" data-dismiss="modal" onclick="myFunction()">Clear</button>
    </div>
    <div class="col-md-6">
   
    </div>

    </div>
</diV>
    </form>
      <hr>
      <br><br>
      
      <h4><small>LIST OF SALE EVENT</small></h4>
      <hr>
      <div class="table-responsive">
      <table id="example" class="table table-bordered table-responsive-lg">
        <tr>
            
            <th>Name</th>
            <th>Discount Type</th>
            <th>Discount Amount</th>
            <th>Date Start</th>
            <th>Date End</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td><?php echo e($sale->name); ?></td>
                <td><?php echo e($sale->discount_type); ?></td>
                <td><?php echo e($sale->discount_amount); ?></td>
                <td><?php echo e($sale->start_date); ?></td>
                <td><?php echo e($sale->end_date); ?></td>
                <td>

<form action="<?php echo e(route('homes.destroy', $sale->id)); ?>" method="post" style="display: inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm"" type="submit">Delete</button>
                  </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
      <hr>

     
      
     
    </div>
  </div>
</div>

<footer class="container-fluid bg-danger">
<div class="text-center">
<p>@2021</p>
</div>
</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Integrative\resources\views/home.blade.php ENDPATH**/ ?>